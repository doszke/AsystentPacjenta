package e.ib.asystentpacjenta;

import android.content.Intent;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import e.ib.asystentpacjenta.businesstier.entities.Hint;
import e.ib.asystentpacjenta.businesstier.service.HintDAO;
import e.ib.asystentpacjenta.businesstier.service.HintRepository;

public class EditActivity extends AppCompatActivity {

    private SQLiteDatabase db;
    private EditText new_token;
    private EditText new_info;
    private TextView mode_tv;
    private TextView chosen_tv;

    private HintDAO hintDAO;
    private List<Hint> hints = new ArrayList<>();

    private Hint selected;

    private int mode;
    private long id;

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_edit);

        db = openOrCreateDatabase("AsystentPacjenta",MODE_PRIVATE,null);
        hintDAO = new HintRepository();

        new_info = (EditText) findViewById(R.id.new_info);
        new_token = (EditText) findViewById(R.id.new_token);
        mode_tv = (TextView) findViewById(R.id.mode_tv);
        chosen_tv = (TextView) findViewById(R.id.chosen_tv);

        hints = hintDAO.fetchAll();

        id = getIntent().getLongExtra("id", -1);
        selected = searchHint(id);
        mode = getIntent().getIntExtra("mode", -2);
        mode_tv.setText(getString(R.string.em_tv_mode) + " " + getString(mode));

        if(mode != R.string.am_btn_add) {
            if(selected != null) {
                chosen_tv.setText(selected.token());
            } else {
                Intent i = new Intent(getApplicationContext(), MainActivity.class);
                i.putExtra("resp", -1);
                finish();
                startActivity(i);
            }
        } else chosen_tv.setText("-");

        if(mode == R.string.am_btn_modify){
            new_token.setText( getIntent().getStringExtra("token") );
            new_info.setText( getIntent().getStringExtra("info") );
        }

    }


    public void onClickExec(View view) {
        Intent i = new Intent(getApplicationContext(), MainActivity.class);

        if(R.string.am_btn_add == mode){
            Hint h = new Hint();
            h.setId(hints.get(hints.size()-1).id() + 1);
            h.setToken(new_token.getText().toString());
            h.setInfo(new_info.getText().toString());
            h.setModified(new Date().toString());
            hintDAO.add(h);
            hints = hintDAO.fetchAll();

            i.putExtra("resp", 1);
        } else if(R.string.am_btn_modify == mode) {
            Hint nh = new Hint();
            nh.setId(id);
            nh.setInfo(new_info.getText().toString());
            nh.setToken(new_token.getText().toString());
            hintDAO.modify(selected, nh);
            i.putExtra("resp", 2);
        } else if (R.string.am_btn_delete == mode) {
            Hint h = new Hint();
            h.setId(selected.id());
            hintDAO.remove(h);
            i.putExtra("resp", 3);
        } else {
            i.putExtra("resp", -1);
        }

        this.finish();
        startActivity(i);
    }


    private Hint searchHint(long id){
        Hint h = new Hint();
        h.setId(id);
        for(Hint hint : hints){
            if(hint.equals(h)){
                return hint;
            }
        }
        return null;
    }

}
