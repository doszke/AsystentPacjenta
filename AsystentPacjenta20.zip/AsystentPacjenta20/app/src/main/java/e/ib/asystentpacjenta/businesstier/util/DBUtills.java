package e.ib.asystentpacjenta.businesstier.util;

import android.database.sqlite.SQLiteDatabase;
import android.os.Build;
import android.util.Log;

import androidx.annotation.RequiresApi;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import e.ib.asystentpacjenta.businesstier.entities.Hint;

public class DBUtills {

    private static final String DROP_DB = "DROP DATABASE IF EXISTS AsystentPacjenta;\n";
    private static final String CREATE_DB = "CREATE DATABASE AsystentPacjenta;\n";
    private static final String CREATE_TABLE = "CREATE TABLE HINTS(id SMALLINT PRIMARY KEY, token VARCHAR(127), info VARCHAR(1023), modified VARCHAR(63));\n";
    private static final String INSERT_TEMPLATE = "INSERT INTO HINTS VALUES(%s, '%s', '%s', '%s');\n";

    public static boolean createBackup(SQLiteDatabase db, List<Hint> data){
        StringBuilder sb = new StringBuilder();

        sb.append(DROP_DB);
        sb.append(CREATE_DB);
        sb.append(CREATE_TABLE);

        for(Hint h : data){
            sb.append(String.format(INSERT_TEMPLATE, h.id(), h.token(), h.info(), h.modified()));
        }

        System.out.println(sb.toString());
        File f = new File("backup.xd");


        return true;
    }


    public static void main(String[] args) {
        String csv = "0, 'Poradnia kardiologiczna', '1 piętro, pokój 1022, rejestracja w holu głównym', 'Wed Jul 31 05:05:49 GMT+02:00 2019';\n" +
                "1, 'Laboratorium', 'parter, za filarem jest korytarz, prosto korytarzem i po lewej stronie', 'Wed Jul 31 05:05:49 GMT+02:00 2019';\n" +
                "2, 'Punkt planowych przyjęć', 'Parter, za filarem korytarzem, w prawo, pierwsze drzwi po lewej stronie', 'Wed Jul 31 05:55:19 GMT+02:00 2019';\n" +
                "3, 'Zdjęcie gipsu', 'SOR za czerwoną budką, za filarem korytarz, prosto i w prawo', 'Wed Jul 31 10:01:03 GMT+02:00 2019';\n" +
                "4, 'Rejestracja numer', '45 9595 454', 'Wed Jul 31 10:04:45 GMT+02:00 2019';\n" +
                "5, 'Poradnia angiologiczna', 'I piętro, pokój 1047, na górę schodami w głównym holu i w lewo', 'Wed Jul 31 10:54:34 GMT+02:00 2019';\n" +
                "6, 'Poradnia chirurgii onkologicznej', '-I piętro, przed stacją dializ w prawo', 'Wed Jul 31 10:56:06 GMT+02:00 2019';\n" +
                "7, 'Poradnia chirurgii naczyniowej', 'I piętro, pokój 1043, na górę schodami w holu głównym i w prawo', 'Wed Jul 31 10:57:39 GMT+02:00 2019';\n" +
                "8, 'Poradnia chorób metabolicznych dla dzieci', 'I piętro, na górę schodami w holu głównym i w prawo do korytarza, do końca, drzwi po prawej stronie', 'Wed Jul 31 11:00:12 GMT+02:00 2019';\n" +
                "9, 'Poradnia dermatologiczna', 'MEDINET, wyjść ze szpitala, prawo i wzdłuż parkingu, 3 piętrowy budynek', 'Wed Jul 31 11:02:14 GMT+02:00 2019';\n" +
                "10, 'Poradnia gastroenterologiczna ', 'I piętro, pokój 1030A, do góry schodami  w holu głównym, w prawo i drzwi będą po lewej stronie ', 'Wed Jul 31 11:05:19 GMT+02:00 2019';\n" +
                "12, 'Poradnia gastroenterologiczna dla dzieci  DRUGIE', 'dr Mozrzymas: I piętro, do góry schodami w holu głównym, w prawo do korytarza, korytarzem prosto, drzwi będą po prawej; dr Kunzig-Gągała i dr Kochańska: parter, za filarem korytarz, prosto, pierwsze w prawo, za budką SORu w lewo ', 'Wed Jul 31 11:18:37 GMT+02:00 2019';\n" +
                "13, 'Poradnia ginekologiczno-położnicza ', 'I piętro, pokój 1030, do góry schodami w holu głównym, w prawo, drzwi będą po lewej stronie; jak coś pilnego to na SOR gin-poł, parter, za filarem korytarzem prosto, w prawo, drugie drzwi po lewej', 'Wed Jul 31 11:22:12 GMT+02:00 2019';\n" +
                "14, 'Poradnia kardiologiczna dla dzieci  ', '-I piętro, na dół schodami w holu głównym, w prawo w korytarz, za kaplicą w lewo', 'Wed Jul 31 11:24:08 GMT+02:00 2019';\n" +
                "15, 'Poradnia nefrologiczna', 'I piętro, pokój 1024, do góry schodami w holu głównym, gabinet na wprost, delikatnie w prawo', 'Wed Jul 31 11:27:42 GMT+02:00 2019';\n" +
                "16, 'Poradnia neonatologiczna', 'I piętro, do góry schodami w holu głównym, w prawo w korytarz, prosto, drzwi po prawej', 'Wed Jul 31 11:29:58 GMT+02:00 2019';\n" +
                "17, 'Poradnia neurologiczna', 'I piętro, pokój 1051, do góry schodami w holu głównym, w lewo do końca, drzwi po lewej', 'Wed Jul 31 11:32:17 GMT+02:00 2019';\n" +
                "18, 'Poradnia neurochirurgiczna', 'I piętro, pokój 1016, do góry schodami w holu głównym,  w lewo, drzwi po lewej', 'Wed Jul 31 11:34:50 GMT+02:00 2019';\n" +
                "19, 'Poradnia okulistyczna', 'I piętro, pokój 1026/1027, do góry schodami w holu głównym,  w prawo, drzwi po lewej będą', 'Wed Jul 31 11:35:46 GMT+02:00 2019';\n" +
                "20, 'Poradnia onkologiczna', '-I piętro, w dół schodami w holu głównym,  w prawo do korytarza, przed stacją dializ w lewo, drugie drzwi po prawej', 'Wed Jul 31 11:39:07 GMT+02:00 2019';\n" +
                "21, 'Poradnia otolaryngologiczna', 'I piętro, pokój 1040, do góry schodami w holu głównym,  w prawo,  czwarte drzwi po prawej', 'Wed Jul 31 11:42:33 GMT+02:00 2019';\n" +
                "22, 'Poradnia onkologii ginekologicznej', 'I piętro, pokój 1017, do góry schodami w holu głównym, w lewo', 'Wed Jul 31 14:14:31 GMT+02:00 2019';\n" +
                "23, 'Poradnia chirurgii urazowo-ortopedycznej', 'I piętro, pokój 1041, do góry schodami w holu głównym, w prawo', 'Wed Jul 31 14:15:17 GMT+02:00 2019';\n" +
                "24, 'Poradnia urologiczna', 'I piętro, pokój 1039, też są 38 37 36, do góry schodami w holu głównym, w prawo', 'Wed Jul 31 14:16:07 GMT+02:00 2019';\n" +
                "25, 'Poradnia stymulacji serca ', 'I piętro, pokój 1023, do góry schodami w holu głównym, lekko w prawo', 'Wed Jul 31 14:17:24 GMT+02:00 2019';\n" +
                "26, 'Poradnia transplantacyjna', 'I piętro, pokój 1049, do góry schodami w holu głównym, w lewo', 'Wed Jul 31 14:19:23 GMT+02:00 2019';\n" +
                "27, 'Depozyt', '-I piętro, schodami w holu głównym w dół, po prawej są drzwi do korytarza, korytarzem prosto, przed stacją dializ w prawo i do końca; w wakacje czynne 7-14.30', 'Wed Jul 31 14:22:02 GMT+02:00 2019';\n" +
                "28, 'Kasa fiskalna', '-I piętro, schodami w holu głównym w dół, po prawej są drzwi do korytarza, korytarzem prosto, przed stacją dializ w prawo, drzwi po lewej; czynne 7-19', 'Wed Jul 31 14:23:43 GMT+02:00 2019';\n" +
                "29, 'Ksero', 'I piętro, lewo od schodów z holu głównego, czynne różnie', 'Wed Jul 31 14:25:11 GMT+02:00 2019';\n" +
                "30, 'Wyzn. terminu: Oddział angiologiczny ', 'SOR kard-nefr-ang, parter, za filarem w korytarz, za windami w prawo, trzecie drzwi po lewej', 'Fri Aug 02 09:11:28 GMT+02:00 2019';\n" +
                "31, 'Przyjęcie: Oddział angiologiczny ', 'Punkt planowych przyjęć, parter, za filarem w korytarz, za windami w prawo, pierwsze drzwi po prawej', 'Fri Aug 02 09:17:57 GMT+02:00 2019';\n" +
                "32, 'Wyzn. terminu: Oddział chemioterapii ', 'Rejestracja w holu głównym', 'Fri Aug 02 09:19:31 GMT+02:00 2019';\n" +
                "33, 'Przyjęcie: Oddział chemioterapii ', 'Kasa fiskalna, - I piętro, schodami w dół, po prawej w drzwi do korytarza, za windami w prawo', 'Fri Aug 02 09:21:52 GMT+02:00 2019';\n" +
                "34, 'Wyznaczenie terminu: Oddział chirurgii ogólnej ', 'pokój 1024, I piętro', 'Fri Aug 02 09:23:40 GMT+02:00 2019';\n" +
                "35, 'Przyjęcie: Oddział chirurgii ogólnej ', 'pokój 1024, I piętro lub Punkt planowych przyjęć, parter, za filarem w korytarz, za windami w prawo, pierwsze drzwi po lewej', 'Fri Aug 02 09:25:16 GMT+02:00 2019';\n" +
                "36, 'Wyznaczenie terminu: Oddział chirurgii naczyniowej ', 'pokój 1024 lub 1043 na I piętrze', 'Fri Aug 02 09:26:45 GMT+02:00 2019';\n" +
                "37, 'Przyjęcie: Oddział chirurgii naczyniowej ', 'Punkt planowych przyjęć, parter, za filarem w korytarz, za windami w prawo, pierwsze drzwi po lewej', 'Fri Aug 02 09:27:29 GMT+02:00 2019';\n" +
                "38, 'Przyjęcie: Oddział chirurgii onkologicznej', 'Punkt planowych przyjęć, parter, za filarem w korytarz, za windami w prawo, pierwsze drzwi po lewej', 'Fri Aug 02 09:27:40 GMT+02:00 2019';\n" +
                "39, 'Wyznaczenie terminu: Oddział chirurgii onkologicznej', 'Rejestracja w holu głównym ', 'Fri Aug 02 09:28:32 GMT+02:00 2019';\n" +
                "40, 'Wyznaczenie terminu: Pododdział chirurgii urazowo-ortopedycznej', 'Sekretariat 3p ', 'Fri Aug 02 09:30:06 GMT+02:00 2019';\n" +
                "41, 'Przyjęcie: Pododdział chirurgii urazowo-ortopedycznej', 'Punkt planowych przyjęć, parter, za filarem w korytarz, za windami w prawo, pierwsze drzwi po lewej', 'Fri Aug 02 09:30:27 GMT+02:00 2019';\n" +
                "42, 'Przyjęcie: Oddział dermatologiczny', 'budynek MEDINET, wyjść ze szpitala, w prawo parkingiem, trzypiętrowy budynek ', 'Fri Aug 02 09:32:46 GMT+02:00 2019';\n" +
                "43, 'Wyznaczenie terminu: Oddział dermatologiczny', 'budynek MEDINET, wyjść ze szpitala, w prawo parkingiem, trzypiętrowy budynek ', 'Fri Aug 02 09:32:56 GMT+02:00 2019';\n" +
                "44, 'Wyznaczenie terminu: Zabieg endoskopowy na podstawie skierowania do szpitala', 'Pracownia endoskopowa, parter, za filarem korytarzem prosto, za windami prosto, drzwi po prawej ', 'Fri Aug 02 09:35:55 GMT+02:00 2019';\n" +
                "45, 'Przyjęcie: Zabieg endoskopowy na podstawie skierowania do szpitala', 'Punkt planowych przyjęć, parter, za filarem w korytarz, za windami w prawo, pierwsze drzwi po lewej', 'Fri Aug 02 09:36:42 GMT+02:00 2019';\n" +
                "46, 'Przyjęcie: Ginekologia operacyjna', 'Punkt planowych przyjęć, parter, za filarem w korytarz, za windami w prawo, pierwsze drzwi po lewej', 'Fri Aug 02 09:37:10 GMT+02:00 2019';\n" +
                "47, 'Wyznaczenie terminu: Ginekologia operacyjna', 'pokój 1018, I piętro', 'Fri Aug 02 09:37:44 GMT+02:00 2019';\n" +
                "48, 'Wyznaczenie terminu: Ginekologiczno-położniczy', 'SOR ginekologiczno-położniczy, parter, za filarem w korytarz, za windami w prawo, drugie drzwi po lewej', 'Fri Aug 02 09:38:37 GMT+02:00 2019';\n" +
                "49, 'Przyjęcie: Ginekologiczno-położniczy', 'SOR ginekologiczno-położniczy, parter, za filarem w korytarz, za windami w prawo, drugie drzwi po lewej', 'Fri Aug 02 09:39:09 GMT+02:00 2019';\n" +
                "50, 'Przyjęcie: Oddział kardiologii', 'Punkt planowych przyjęć, parter, za filarem w korytarz, za windami w prawo, pierwsze drzwi po lewej', 'Fri Aug 02 09:40:27 GMT+02:00 2019';\n" +
                "51, 'Wyznaczenie terminu: Oddział kardiologii', 'SOR kard-nefr-ang, parter, za filarem w korytarz, za windami w prawo, trzecie drzwi po lewej', 'Fri Aug 02 09:41:51 GMT+02:00 2019';\n" +
                "52, 'Wyznaczenie terminu: Oddział kardiologii dziecięcej', 'Izba przyjęć na oddziale pediatrycznym, parter, za filarem korytarzem prosto, za windami w prawo, przed budką SORu w lewo, do końca', 'Fri Aug 02 09:44:47 GMT+02:00 2019';\n" +
                "53, 'Przyjęcie: Oddział kardiologii dziecięcej', 'Punkt planowych przyjęć, parter, za filarem w korytarz, za windami w prawo, pierwsze drzwi po lewej', 'Fri Aug 02 09:46:05 GMT+02:00 2019';\n" +
                "54, 'Wyznaczenie terminu: Oddział neonatologiczny', 'Izba przyjęć na oddziale pediatrycznym, parter, za filarem w korytarz prosto, za windami w prawo, przed budką SORu w lewo, prosto do konca', 'Fri Aug 02 09:48:16 GMT+02:00 2019';\n" +
                "55, 'Przyjęcie: Oddział neonatologiczny', 'Izba przyjęć na oddziale pediatrycznym, parter, za filarem w korytarz prosto, za windami w prawo, przed budką SORu w lewo, prosto do konca', 'Fri Aug 02 09:48:27 GMT+02:00 2019';\n" +
                "56, 'Przyjęcie: Oddział nefrologiczny', 'Punkt planowych przyjęć, parter, za filarem w korytarz, za windami w prawo, pierwsze drzwi po lewej', 'Tue Aug 06 07:29:48 GMT+02:00 2019';\n" +
                "57, 'Wyznaczenie terminu: Oddział nefrologiczny', 'SOR kard-nefr-ang , parter, za filarem w korytarz, za windami w prawo, trzecie drzwi po lewej', 'Fri Aug 02 09:50:29 GMT+02:00 2019';\n" +
                "58, 'Przyjęcie: Oddział okulistyczny', 'Punkt planowych przyjęć, parter, za filarem w korytarz, za windami w prawo, pierwsze drzwi po lewej', 'Tue Aug 06 07:30:14 GMT+02:00 2019';\n" +
                "59, 'Przyjęcie: Oddział otolaryngologiczny', 'Punkt planowych przyjęć, parter, za filarem w korytarz, za windami w prawo, pierwsze drzwi po lewej', 'Tue Aug 06 07:31:13 GMT+02:00 2019';\n" +
                "60, 'Przyjęcie: Oddział pediatryczny', 'Punkt planowych przyjęć, parter, za filarem w korytarz, za windami w prawo, pierwsze drzwi po lewej', 'Tue Aug 06 07:33:17 GMT+02:00 2019';\n" +
                "61, 'Przyjęcie: Oddział pediatryczny', 'POPRAW NA PPP 3 WCZESNIEJ', 'Fri Aug 02 09:52:49 GMT+02:00 2019';\n" +
                "62, 'Przyjęcie: Oddział urologii i urologii onkologicznej', 'najpierw izba przyjęć na p5, potem Punkt planowych przyjęć, parter, za filarem w korytarz, za windami w prawo, pierwsze drzwi po lewej', 'Fri Aug 02 09:54:07 GMT+02:00 2019';\n" +
                "63, 'Wyznaczenie terminu: Oddział urologii i urologii onkologicznej', 'Poradnia urologiczna, p1 bez kolejki', 'Fri Aug 02 09:55:04 GMT+02:00 2019';\n" +
                "64, 'Wyznaczenie terminu: Oddział urologii i urologii onkologicznej', 'Hol główny', 'Fri Aug 02 09:55:22 GMT+02:00 2019';\n" +
                "65, 'Wyznaczenie terminu: Oddział pediatryczny', 'Izba przyjęć na oddziale pediatrycznym, parter, za filarem w korytarz prosto, za windami w prawo, przed budką SORu w lewo, do końca', 'Fri Aug 02 09:56:34 GMT+02:00 2019';\n" +
                "66, 'Wyznaczenie terminu: Oddział otolaryngologiczny', 'Hol główny, bez numerka', 'Fri Aug 02 09:57:17 GMT+02:00 2019';\n" +
                "67, 'Wyznaczenie terminu: Oddział okulistyczny', 'Poradnia okulistyczna, I piętro', 'Fri Aug 02 09:57:46 GMT+02:00 2019';\n" +
                "68, 'Zamiejscowa Poradnia Urazowo-ortopedyczna', 'ul. Poświęcka 8, można dojechać 930 -> Krzyżanowice lub 130 - > Polanowice, przystanek Ługowa, skręcić w lewo i przejść około 700m', 'Tue Aug 06 08:59:06 GMT+02:00 2019';\n" +
                "69, 'Badanie: Angiografia', 'Na oddziale angiologicznym, 2p', 'Tue Aug 06 09:06:03 GMT+02:00 2019';\n" +
                "70, 'Badanie Błędnika ', 'gabinet 1031, 1 piętro, zaplanowany zabieg i do wyznaczenia terminu', 'Tue Aug 06 09:07:14 GMT+02:00 2019';\n" +
                "71, 'Badanie: Biopsja', 'do wyznaczenia terminu- skierowanie z oddziałów, postępować wg zaleceń; zaplanowane przyjęcie- punkt przyjęć planowych ', 'Tue Aug 06 09:12:15 GMT+02:00 2019';\n" +
                "72, 'Badanie EKG', 'przyjęcie i badanie na - 1 piętrze, korytarzem prosto, za kaplicą w lewo', 'Tue Aug 06 09:14:45 GMT+02:00 2019';\n" +
                "73, 'Badanie: Endoskopia, Gastroskopia, Kolonoskopia', 'do wyznaczenia terminu- hol główny, pobrać numerek; badanie- pracownia endoskopowa, za filarem korytarzem prosto, mijamy chirurgię c, po prawej drzwi; DILO bez kolejki', 'Tue Aug 06 09:17:24 GMT+02:00 2019';\n" +
                "74, 'Badanie: Holter', 'dorośli: 4 piętro na oddziale kardiologicznym, dzieci na 1 piętrze, na oddziale kardiologii dziecięcej', 'Tue Aug 06 09:55:38 GMT+02:00 2019';\n" +
                "75, 'Badanie: KTG', 'SOR ginekologiczno-położniczy, za filarem korytarzem prosto, za windami w prawo, drugie drzwi po lewej', 'Tue Aug 06 09:56:33 GMT+02:00 2019';\n" +
                "76, 'Badanie: Morfologia i inne badania krwi ', 'Laboratorium, za filarem w korytarz, szklane drzwi po lewej', 'Tue Aug 06 09:58:15 GMT+02:00 2019';\n" +
                "77, 'Badanie: Laparoskopia', 'do wyznaczenia terminu- skierowana z oddziałów, postępować wg zaleceń; badanie- pokój 1024', 'Tue Aug 06 10:11:48 GMT+02:00 2019';\n" +
                "78, 'Badanie: OCT', 'po zakropieniu oczu w poradni okulistycznej lub w poradni retinopatii udać się do gabinetu zabiegowego na oddziale okulistycznym 6 piętro ', 'Tue Aug 06 10:15:19 GMT+02:00 2019';\n" +
                "79, 'Badanie: Samobadanie Piersi', 'poradnia onkologiczna, - 1 piętro, przed stacją dializ w lewo', 'Tue Aug 06 10:18:33 GMT+02:00 2019';\n" +
                "80, 'Badanie: Przepływy', 'do wyznaczenia terminu- hol główny bez numerka, tylko że skierowaniem do poradni chirurgii naczyniowej; badanie: poradnia chirurgii naczyniowej / angiologiczna, 1 piętro, 1043 ', 'Tue Aug 06 10:26:38 GMT+02:00 2019';\n" +
                "81, 'Badanie: RTG, Rentgen', 'rejestracja RTG, 1 piętro, schodami w holu głównym do góry, po prawej są drzwi do korytarza, korytarzem prosto, pierwsze w lewo ', 'Tue Aug 06 10:28:11 GMT+02:00 2019';\n" +
                "82, 'Badanie: Rezonans Magnetyczny, MRI', 'hol główny, pobrać numerek ', 'Tue Aug 06 10:29:50 GMT+02:00 2019';\n" +
                "83, 'Badanie Sutka', 'poradnia onkologiczna, schodami w holu głównym w dół, po prawej są drzwi do korytarza, korytarzem prosto, za windami w lewo, pierwsze drzwi po prawej ', 'Tue Aug 06 10:31:22 GMT+02:00 2019';\n" +
                "84, 'Badanie: Tomografia Komputerowa, TK, CT', 'hol główny, pobrać numerek ', 'Tue Aug 06 10:32:08 GMT+02:00 2019';\n" +
                "85, 'Badanie: Ultrasonografia, USG', 'samo badanie jest na 2 piętrze, zgłosić się do rejestracji RTG na 1 piętrze, schodami w holu głównym do góry, po prawej są drzwi do korytarza, korytarzem prosto, pierwsze w lewo', 'Tue Aug 06 10:40:44 GMT+02:00 2019';\n" +
                "86, 'Badanie: USG Doppler', 'do wyznaczenia terminu- hol główny, pobrać numerek, tylko że skierowaniem do poradni chirurgii naczyniowej; badanie- do rejestracji RTG na 1 piętrze, schodami w holu głównym do góry, po prawej są drzwi do korytarza, korytarzem prosto, pierwsze w lewo', 'Tue Aug 06 10:58:43 GMT+02:00 2019';\n" +
                "87, 'Badanie: USG Serca', 'na - 1 piętrze, schodami w holu głównym w dół, po prawej są drzwi do korytarza, za kaplicą w lewo, pierwsze drzwi po lewej ', 'Tue Aug 06 10:59:48 GMT+02:00 2019';\n" +
                "88, 'Badanie: Mammografia, RTG Piersi ', 'rejestracja RTG, schodami w holu głównym do góry, po prawej są drzwi do korytarza, korytarzem prosto, pierwsze w lewo ', 'Tue Aug 06 11:00:41 GMT+02:00 2019';\n" +
                "89, 'Badanie: Retinopatia Wcześniaków', '-1 piętro, schodami w holu głównym w dół, po prawej są drzwi do korytarza, za kaplicą w lewo, ostatnie drzwi po lewej ', 'Tue Aug 06 11:04:29 GMT+02:00 2019';\n" +
                "90, 'Badanie: Wycięcie Migdałków I Inne Zabiegi Laryngologiczne ', 'do wyznaczenia terminu- hol główny, bez numerka we wtorek o 7:00; badanie zgodnie ze skierowaniem ', 'Tue Aug 06 11:18:32 GMT+02:00 2019'";


        List<Hint> hints = new ArrayList<>(90);
        for(String str : csv.split(";\n")){

            String[] parts = str.split(",");
            hints.add(new Hint(
                    Long.parseLong(parts[0]), parts[0].replace("'", ""), parts[0].replace("'", ""), parts[0].replace("'", "")
            ));

        }

        Hint h = hints.get(40);

        System.out.println(h.id());
        System.out.println(h.token());
        System.out.println(h.info());
        System.out.println(h.modified());
    }
}
