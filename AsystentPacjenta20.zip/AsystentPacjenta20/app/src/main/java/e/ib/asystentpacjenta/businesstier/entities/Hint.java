package e.ib.asystentpacjenta.businesstier.entities;

import android.database.Cursor;

import java.util.ArrayList;
import java.util.List;
import java.util.Objects;

public class Hint {

    private Long id;
    private String token;
    private String info;

    private String modified;

    public Hint(){ }

    public Hint(Long id, String token, String info, String modified) {
        this.id = id;
        this.token = token;
        this.info = info;
        this.modified = modified;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        Hint hint = (Hint) o;
        return id.equals(hint.id);
    }

    @Override
    public int hashCode() {
        return Objects.hash(id);
    }

    public static List<Hint> hintsFromCursor(Cursor c){
        List<Hint> hints = new ArrayList<>();
        Hint h = new Hint();
        while(c.moveToNext()){
            h.id = c.getLong(0);
            h.token = c.getString(1);
            h.info = c.getString(2);
            h.modified = c.getString(3);
            hints.add(h);
            h = new Hint();
        }
        return hints;
    }

    public Long id() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String token() {
        return token;
    }

    public void setToken(String token) {
        this.token = token;
    }

    public String info() {
        return info;
    }

    public void setInfo(String info) {
        this.info = info;
    }

    public String modified() {
        return modified;
    }

    public void setModified(String modified) {
        this.modified = modified;
    }

    @Override
    public String toString() {
        return "Hint{" +
                "id=" + id +
                ", token='" + token + '\'' +
                ", info='" + info + '\'' +
                ", modified='" + modified + '\'' +
                '}';
    }
}
