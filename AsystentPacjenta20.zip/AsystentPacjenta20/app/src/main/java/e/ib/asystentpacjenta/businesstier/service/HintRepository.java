package e.ib.asystentpacjenta.businesstier.service;

import android.content.ContentValues;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;

import com.google.firebase.firestore.FirebaseFirestore;

import java.util.Date;
import java.util.List;

import e.ib.asystentpacjenta.businesstier.entities.Hint;

public class HintRepository implements HintDAO {

    private final FirebaseFirestore firestore = FirebaseFirestore.getInstance();

    public HintRepository() {

    }

    @Override
    public void add(Hint h) {
        ContentValues c = new ContentValues();
        /*
        Class cls = c.getClass();
        for(Field f : cls.getFields()){
            Method meth = null;
            for(Method m : cls.getMethods()){
                if(m.getName().equals(f.getName())){
                    meth = m;
                    break;
                }
            }
            if(f.getName().equals("id")) {
                c.put(f.getName(), (long)meth.invoke(h));
            } else {
                c.put(f.getName(), (String)meth.invoke(h));
            }
        }*/
        c.put("id", h.id());
        c.put("token", h.token());
        c.put("info", h.info());
        c.put("modified", h.modified());

        //db.insert("HINTS", null, c);
    }

    @Override
    public void remove(Hint h) {
        //db.delete("HINTS", "id =" +  h.id(), null);
    }

    @Override
    public void modify(Hint oh, Hint nh) {
        ContentValues c = new ContentValues();
        c.put("token", nh.token());
        c.put("info", nh.info());
        c.put("modified", new Date().toString());

        //db.update("HINTS", c, "id = " + oh.id(), null);
    }

    @Override
    public List<Hint> fetchAll() {
        //Cursor c = db.rawQuery("SELECT * FROM HINTS ORDER BY ID", new String[]{});
        return null;//Hint.hintsFromCursor(c);
    }


}
