package e.ib.asystentpacjenta.businesstier.service;

import java.util.List;

import e.ib.asystentpacjenta.businesstier.entities.Hint;

public interface HintDAO {

    void add(Hint h);

    void remove(Hint h);

    void modify(Hint oh, Hint nh);

    List<Hint> fetchAll();

}
