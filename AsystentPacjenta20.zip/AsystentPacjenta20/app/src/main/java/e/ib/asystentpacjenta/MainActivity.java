package e.ib.asystentpacjenta;

import android.content.Intent;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.os.Environment;
import android.support.v7.app.AppCompatActivity;
import android.text.Editable;
import android.text.TextWatcher;
import android.util.Log;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import java.io.File;
import java.util.ArrayList;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import e.ib.asystentpacjenta.businesstier.entities.Hint;
import e.ib.asystentpacjenta.businesstier.service.HintDAO;
import e.ib.asystentpacjenta.businesstier.service.HintRepository;
import e.ib.asystentpacjenta.businesstier.util.DBUtills;


public class MainActivity extends AppCompatActivity implements AdapterView.OnItemSelectedListener {

    private HintDAO hintDAO;
    private List<Hint> hints;

    private TextView text_info;
    private EditText text_token;
    private Spinner hintSpinner;

    private ArrayAdapter<String> adapter;
    private List<Integer> position = new ArrayList<>();


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        hintDAO = new HintRepository();
        int resp = getIntent().getIntExtra("resp",-2);

        if(resp == 1){
            Toast.makeText(getApplicationContext(), "Dodano wskazówkę", Toast.LENGTH_SHORT).show();
        } else if (resp == 2) {
            Toast.makeText(getApplicationContext(), "Zaedytowano wskazówkę", Toast.LENGTH_SHORT).show();
        } else if (resp == 3){
            Toast.makeText(getApplicationContext(), "Usunięto wskazówkę", Toast.LENGTH_SHORT).show();
        } else if (resp == -1){
            Toast.makeText(getApplicationContext(), "Coś poszło nie tak... Spróbuj ponownie", Toast.LENGTH_SHORT).show();
        }

        //db.execSQL("DROP TABLE HINTS");
        //db.execSQL("CREATE TABLE HINTS(id SMALLINT PRIMARY KEY, token VARCHAR(127), info VARCHAR(1023), modified VARCHAR(63))");

        //Hint h = new Hint(0l, "Poradnia kardiologiczna", "1 piętro\npokój 1022\nrejestracja w holu głównym", new Date().toString());
        //hintDAO.add(h);

        //h = new Hint(1l, "Laboratorium", "parter\nza filarem jest korytarz, prosto korytarzem i po lewej stronie", new Date().toString());
        //hintDAO.add(h);

        hints = hintDAO.fetchAll();

        text_info = (TextView) findViewById(R.id.text_info);
        text_token = (EditText) findViewById(R.id.token_info);
        hintSpinner = (Spinner) findViewById(R.id.searchList);


        for(Hint h : hints){
            if(h.token().equals("iksde")){
                Log.d("XDDDDDDDDD", String.valueOf(h.id()));
            }
        }

        adapter = new ArrayAdapter<>(this,android.R.layout.simple_spinner_item);

        hintSpinner.setAdapter(adapter);
        hintSpinner.setOnItemSelectedListener(this);


        text_token.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {
                adapter.clear();
                position.clear();
            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {
                Log.d( "DEBUG", text_token.getText().toString());
                String inputs = text_token.getText().toString().toLowerCase();

                /*
                Wyszukiwarka ma na celu przesortowanie wszystkich wskazówek
                i wybranie tylko tych, w których występują wszystkie wpisane
                przez użytkownika słowa.
                 */
                String[] words = inputs.trim().split(" ");
                List<String> help = new ArrayList<>();
                List<Integer> helpPos = new ArrayList<>();
                boolean isFirst = true;

                //każde słowo wyszukane osobno
                for(String input : words) {
                    List<String> actual = new ArrayList<>();
                    List<Integer> actualPos = new ArrayList<>();

                    Pattern pattern = Pattern.compile(input.trim());
                    Matcher matcher;
                    for (int i = 0; i < hints.size(); i++) {
                        Hint h = hints.get(i);
                        matcher = pattern.matcher(h.token().toLowerCase());
                        if (matcher.find()) { //szukam wystąpienia
                            if(isFirst) { //pierwszy obrót dodaje wszystko, by potem to przesiewać
                                actual.add(h.token());
                                actualPos.add(i);
                            } else { //każdy kolejny sprawdza, czy zostało już dodane- wszystkie 'słowa' muszą wystąpić
                                if(help.contains(h.token())){
                                    actual.add(h.token());
                                    helpPos.add(i);
                                }
                            }
                        }
                    }
                    isFirst = false; //każdy kolejny obrót nie jest pierwszym
                    help = actual; //ustawiam pomocnicze listy
                    helpPos = actualPos;
                }
                //ustawiam główne listy
                adapter.addAll(help);
                position = helpPos;

                if (!position.isEmpty()) {
                    text_info.setText(hints.get(position.get(0)).info());
                }
            }

            @Override
            public void afterTextChanged(Editable s) {
                hintSpinner.setSelection(0);
            }
        });
    }



    @Override
    public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
        int pos = this.position.get(position);
        text_info.setText(hints.get(pos).info());
    }

    @Override
    public void onNothingSelected(AdapterView<?> parent) {
        text_info.setText("");
    }


    private boolean isPresent(Hint h){
        for(int i = 0; i < adapter.getCount(); i++){
            if(h.token().equals(adapter.getItem(i))){
                return true;
            }
        }
        return false;
    }

    //btn listeners
    public void onClickAdd(View view) {
        Intent intent = new Intent(getApplicationContext(), EditActivity.class);
        intent.putExtra("mode", R.string.am_btn_add);
        startActivity(intent);
    }

    public void onClickEdit(View view) {
        Hint h = hints.get(position.get((int)hintSpinner.getSelectedItemId()));
        Intent intent = new Intent(getApplicationContext(), EditActivity.class);
        intent.putExtra("mode", R.string.am_btn_modify);
        intent.putExtra("id", h.id());
        intent.putExtra("token", h.token());
        intent.putExtra("info", h.info());
        startActivity(intent);
    }

    public void onClickDelete(View view) {
        Intent intent = new Intent(getApplicationContext(), EditActivity.class);
        intent.putExtra("mode", R.string.am_btn_delete);
        Log.d("XDDDDDDDDDDD2", String.valueOf(hints.get(position.get((int)hintSpinner.getSelectedItemId())).id()));
        intent.putExtra("id", hints.get(position.get((int)hintSpinner.getSelectedItemId())).id());
        startActivity(intent);
    }

    private void backup(){
        File dir = new File(Environment.getExternalStorageDirectory() + "/backup/");
        if(! dir.exists()){
            if(dir.mkdir()) Log.i("BACKUP", "Created directory " + dir.getAbsolutePath());
        }

    }

    private void exportDB(){
        List<Hint> backup = hintDAO.fetchAll(); //dla pewności
        //TODO implement me

    }

    private void importDB(){
        //TODO implement me
    }


}
